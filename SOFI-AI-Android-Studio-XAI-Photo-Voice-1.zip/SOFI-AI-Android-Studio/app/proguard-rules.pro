# SOFI AI does not require custom ProGuard rules.
