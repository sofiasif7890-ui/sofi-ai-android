# SOFI AI Android Studio Project

This Android Studio project packages the current SOFI AI HTML app as a native Android WebView app.

## Current media features
- Text chat continues through the Supabase `sofi-chat` Edge Function and Groq.
- Image generation uses xAI Grok Imagine through the same authenticated Edge Function.
- Voice replies use xAI Text-to-Speech through the same Edge Function, with browser speech fallback.
- Photo attachment lets the user select a JPG/PNG and ask SOFI AI about it using xAI image understanding.

## Required Supabase secret
Add `XAI_API_KEY` to the Supabase Edge Function secrets for project `rrionpaqripjkkwetgzz`.

Do not put `XAI_API_KEY` in `index.html`, the Android app, or the APK.

## Build
Open this folder in Android Studio, sync Gradle, then use Build > Build APK(s).

The debug APK will normally appear at:
`app/build/outputs/apk/debug/app-debug.apk`
